#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <fstream>

using namespace std;
using namespace cv;

const float inlier_threshold = 2.5f; // Distance threshold to identify inliers
const float nn_match_ratio = 0.8f;   // Nearest neighbor matching ratio
const double M_PI = 3.141592653589793;


// Photo information
const int nSideLayer = 4; //1;
const int nPhoto = 26; //21;
const int nPhotoSide[2][nSideLayer] = { { 25, 23, 20, 18 }, { 25, 24, 23, 21} }; //{ { 20 }, { 19 } };
const int indexPhotoSide[2][nSideLayer] = { { 26, 51, 74, 94 }, { 112, 137, 161, 184 } }; //{ { 21 }, { 41 } }; 
const double cInit = 1830; //940;
const double projectionThreshold = 0.4; //0;
const int faceSize = 1024;
const int scaledFaceSize = 512;

int totalPhoto;

// High contrast photos
Mat Ring[nPhoto];
Mat RingH[nPhoto];
Mat* SideRing[2][nSideLayer];

// Original photos
Mat RingOriginal[nPhoto];
Mat* SideRingOriginal[2][nSideLayer];

// Rotations
Mat Rot[nPhoto];
Mat* SideRot[2][nSideLayer];

// Values of alpha
double cRing[nPhoto];
double* cSideRing[2][nSideLayer];

// Photo indexes
int index[nPhoto];
int* sideIndex[2][nSideLayer];

// Six faces of the skybox
Mat Faces[6];
Mat FacesZbuffer[6];
Mat FaceRot[6];
double FaceScreenPosX[6]{0, scaledFaceSize, 2 * scaledFaceSize, 0, scaledFaceSize, 2*scaledFaceSize};
double FaceScreenPosY[6]{0, 0, 0, scaledFaceSize, scaledFaceSize, scaledFaceSize};

Mat Offset;
Mat Offinv;
Mat FaceOffset;

Mat bigR;

const int ptsn = 9;
const int ptsx[ptsn] = { -500, 0, 500, -500, 0, 500, -500, 0, 500 };
const int ptsy[ptsn] = { -500, -500, -500, 0, 0, 0, 500, 500, 500 };
Mat pts[ptsn];
ofstream o;


// Project a photo on the faces of the skybox using a rotation and a coefficient alpha
void project(Mat& RotInv, Mat& Img, double c) {
	double interp = 40000;
	Mat coordR = Mat::ones(3, 1, CV_64F);

	cout << "alpha = " << c << endl;
	for (int f = 0; f < 6; f++) {
		Mat RealRot = RotInv.t();
		if (RealRot.col(2).dot(FaceRot[f].col(2)) > projectionThreshold) {
			Mat H = FaceRot[f].t() * RealRot;
			H.at<double>(0, 2) *= c;
			H.at<double>(1, 2) *= c;
			H.at<double>(2, 0) /= faceSize / 2.0;
			H.at<double>(2, 1) /= faceSize / 2.0;
			H.at<double>(2, 2) *= c / (faceSize / 2.0);
			Mat HInv = H.inv();
			Mat RealH = FaceOffset * H * Offset;
			

			Mat R;
			warpPerspective(Img, R, RealH, Size(faceSize, faceSize));
			for (int i = 0; i < Faces[f].rows; i++) {
				for (int j = 0; j < Faces[f].cols; j++) {
					Vec3b c1 = Faces[f].at<Vec3b>(i, j);
					Vec3b c2 = R.at<Vec3b>(i, j);
					if (c2.dot(c2) != 0 ) {
						coordR.at<double>(0, 0) = j - (faceSize - 1) / 2.0;
						coordR.at<double>(1, 0) = i - (faceSize - 1) / 2.0;
						coordR.at<double>(2, 0) = 1;
						Mat coordImg = HInv * coordR;
						coordImg /= coordImg.at<double>(2, 0);
						coordImg.at<double>(2, 0) = 0;
						double z = c * c + coordImg.dot(coordImg);
						double dz = z - FacesZbuffer[f].at<double>(i, j);

						//Faces[f].at<Vec3b>(i, j) = Vec3b(max(c1[0], c2[0]), max(c1[1], c2[1]), max(c1[2], c2[2]));
						if (dz < - interp) {
							Faces[f].at<Vec3b>(i, j) = c2;
						}
						else if (dz < interp) {
							double coeff = 0.5 - dz / (2 * interp);
							Faces[f].at<Vec3b>(i, j) = c2 * coeff + c1 * (1-coeff);
						}
						if (dz < 0) {
							FacesZbuffer[f].at<double>(i, j) = z;
						}
					}
				}
			}

			for (int i = 0; i < scaledFaceSize; i++) {
				for (int j = 0; j < scaledFaceSize; j++) {
					bigR.at<Vec3b>(i + FaceScreenPosY[f], j + FaceScreenPosX[f]) = Faces[f].at<Vec3b>(i * faceSize / scaledFaceSize, j * faceSize / scaledFaceSize);
				}
			}
		}
	}
}

// Find the homography between two photos. Center is (0,0).
Mat findCentricPhotoHomography(Mat& I1, Mat& I2) {
	vector<KeyPoint> kpts1, kpts2;
	Mat desc1, desc2;

	Ptr<AKAZE> akaze = AKAZE::create();
	akaze->detectAndCompute(I1, noArray(), kpts1, desc1);
	akaze->detectAndCompute(I2, noArray(), kpts2, desc2);
	/*Ptr<ORB> orb = ORB::create();
	orb->detectAndCompute(I1, noArray(), kpts1, desc1);
	orb->detectAndCompute(I2, noArray(), kpts2, desc2);*/

	if (kpts1.size() == 0 || kpts2.size() == 0) {
		return Mat();
	}

	BFMatcher matcher(NORM_HAMMING);
	vector< vector<DMatch> > nn_matches;
	matcher.knnMatch(desc1, desc2, nn_matches, 2);

	vector<KeyPoint> matched1, matched2, inliers1, inliers2;
	vector<Point2f> matched1pts, matched2pts;
	vector<DMatch> id, id2;
	cout << "Number of AKAZE points in the new image: " << kpts2.size() << endl;
	for (int i = 0; i < nn_matches.size(); i++) {
		DMatch first = nn_matches[i][0];
		float dist1 = nn_matches[i][0].distance;
		float dist2 = nn_matches[i][1].distance;
		if (dist1 < nn_match_ratio * dist2) {
			int t = matched1.size();
			matched1.push_back(kpts1[first.queryIdx]);
			matched2.push_back(kpts2[first.trainIdx]);
			matched1pts.push_back(kpts1[first.queryIdx].pt);
			matched2pts.push_back(kpts2[first.trainIdx].pt);
			id.push_back(DMatch(t, t, 0));
		}
	}
	return Offset * findHomography(matched1pts, matched2pts, CV_RANSAC) * Offinv;
}


// Loading and initialization
void init() {
	cout << "Begin image loading..." << endl;
	char filename[50];
	int num = 1;
	cout << "First ring:" << endl;
	for (int i = 0; i < nPhoto-1; i++) {
		sprintf(filename, "../HighContrast/IMG-%d.JPG", num);
		cout << filename << endl;
		Ring[i] = imread(string(filename));

		sprintf(filename, "../Original/IMG-%d.JPG", num);
		cout << filename << endl;
		RingOriginal[i] = imread(string(filename));

		num++;
	}
	Ring[nPhoto - 1] = Ring[0];
	RingOriginal[nPhoto - 1] = RingOriginal[0];
	for (int s = 0; s <= 1; s++) {
		for (int l = 0; l < nSideLayer; l++) {
			cout << "Layer " << (l+1) << (s == 0 ? " up: ":" down: ") << endl;
			SideRing[s][l] = new Mat[nPhotoSide[s][l]];
			SideRingOriginal[s][l] = new Mat[nPhotoSide[s][l]];
			SideRot[s][l] = new Mat[nPhotoSide[s][l]];
			cSideRing[s][l] = new double[nPhotoSide[s][l]];
			num = indexPhotoSide[s][l];
			for (int i = 0; i < nPhotoSide[s][l]; i++) {
				sprintf(filename, "../HighContrast/IMG-%d.JPG", num);
				cout << filename << endl;
				SideRing[s][l][i] = imread(string(filename));

				sprintf(filename, "../Original/IMG-%d.JPG", num);
				cout << filename << endl;
				SideRingOriginal[s][l][i] = imread(string(filename));

				num++;
			}
		}
	}

	for (int i = 0; i < 6; i++) {
		Faces[i].create(faceSize, faceSize, CV_8UC3);
		Faces[i] = 0;
		FacesZbuffer[i].create(faceSize, faceSize, CV_64F);
		FacesZbuffer[i] = 1000000000000;
	}
	FaceRot[1].create(3, 3, CV_64F);
	FaceRot[1] = 0;
	FaceRot[1].at<double>(2, 0) = -1;
	FaceRot[1].at<double>(1, 1) = 1;
	FaceRot[1].at<double>(0, 2) = 1;
	FaceRot[0] = FaceRot[1] * FaceRot[1].t();
	FaceRot[2] = FaceRot[1] * FaceRot[1];
	FaceRot[3] = FaceRot[1].t();
	FaceRot[4].create(3, 3, CV_64F);
	FaceRot[4] = 0;
	FaceRot[4].at<double>(0, 0) = 1;
	FaceRot[4].at<double>(2, 1) = 1;
	FaceRot[4].at<double>(1, 2) = -1;
	FaceRot[5] = FaceRot[4].t();

	Rot[0] = FaceRot[0].clone();
	cRing[0] = cInit;

	Offset.create(3, 3, CV_64F);
	Offset = 0.0;
	Offset.at<double>(0, 0) = 1;
	Offset.at<double>(1, 1) = 1;
	Offset.at<double>(2, 2) = 1;
	Offset.at<double>(0, 2) = -(Ring[0].cols + 1) / 2.0;
	Offset.at<double>(1, 2) = -(Ring[0].rows + 1) / 2.0;
	Offinv = Offset.inv();
	FaceOffset = Offset.clone();
	FaceOffset.at<double>(0, 2) = (faceSize + 1) / 2.0;
	FaceOffset.at<double>(1, 2) = (faceSize + 1) / 2.0;

	bigR.create(scaledFaceSize * 2, scaledFaceSize * 3, CV_8UC3);
	bigR = 0;


	index[nPhoto - 1] = 0;
	for (int k = 0; k < nPhoto - 1; k++) {
		index[k] = k;
	}
	int nextIndex = nPhoto - 1;
	for (int s = 0; s <= 1; s++) {
		for (int l = 0; l < nSideLayer; l++) {
			sideIndex[s][l] = new int[nPhotoSide[s][l]];
			for (int i = 0; i < nPhotoSide[s][l]; i++) {
				sideIndex[s][l][i] = nextIndex++;
			}
		}
	}

	totalPhoto = nPhoto - 1;
	for (int s = 0; s <= 1; s++) {
		for (int l = 0; l < nSideLayer; l++) {
			totalPhoto += nPhotoSide[s][l];
		}
	}
	for (int k = 0; k < ptsn; k++) {
		pts[k] = Mat::ones(3, 1, CV_64F);
		pts[k].at<double>(0, 0) = ptsx[k];
		pts[k].at<double>(1, 0) = ptsy[k];
	}
}

void outputH(int index1, int index2, Mat H) {
	for (int k = 0; k < ptsn; k++) {
		Mat temp = H * pts[k];
		temp /= temp.at<double>(2, 0);
		//o << index1 << " " << index2 << " " << (k + 1) << " 1  " << temp.at<double>(0, 0) << endl;
		//o << index1 << " " << index2 << " " << (k + 1) << " 2  " << temp.at<double>(1, 0) << endl;
		o << index1 << " " << index2 << " " << ptsx[k] << " " << ptsy[k] << " " << temp.at<double>(0, 0) << " " << temp.at<double>(1, 0) << endl;
	}
}

void outputFile() {
	//ampl file
	/*o.open("skybox.dat");

	o << "param nPhoto := " << totalPhoto << ";" << endl;
	o << "set Rel := " << endl;
	for (int i = 1; i < nPhoto; i++) {
	o << "(" << i << "," << (i + 1 == nPhoto ? 1 : i + 1) << ")" << endl;
	o << "(" << (i + 1 == nPhoto ? 1 : i + 1) << "," << i << ")" << endl;
	}
	o << ";" << endl;
	o << "param k := " << ptsn << ";" << endl;
	o << "param pts := " << endl;
	for (int k = 0; k < ptsn; k++) {
	o << (k + 1) << " 1  " << ptsx[k] << endl;
	o << (k + 1) << " 2  " << ptsy[k] << endl;
	}
	o << ";" << endl;
	o << "param alpha := " << cInit << ";" << endl;
	o << "param Hpts := " << endl;

	cout << "Begin horizontal ring:" << endl;
	cout << "Photo 1" << endl;
	for (int k = 1; k < nPhoto; k++) {
	cout << "Photo " << (k+1) << endl;
	RingH[k] = findCentricPhotoHomography(Ring[k - 1], Ring[k]);
	outputH(k, (k + 1 == nPhoto ? 1 : k + 1), RingH[k]);
	outputH((k + 1 == nPhoto ? 1 : k + 1), k, RingH[k].inv());
	}

	o << ";" << endl;
	o.close();*/




	// Ceres file
	o.open("solver_input.txt");

	o << totalPhoto << " " << (totalPhoto * 2 - (nPhoto - 1)) * 18 << " " << (1 + 2 * nSideLayer) << std::endl;
	o << nPhoto - 1;
	for (int s = 0; s <= 1; s++) {
		for (int l = 0; l < nSideLayer; l++) {
			o << " " << nPhotoSide[s][l];
		}
	}
	o << std::endl;

	cout << "Begin horizontal ring:" << endl;
	cout << "Photo 1" << endl;
	project(Rot[0], RingOriginal[0], cRing[0]);
	for (int k = 1; k < nPhoto; k++) {
		cout << "Photo " << (k + 1) << endl;
		RingH[k] = findCentricPhotoHomography(Ring[k - 1], Ring[k]);
		outputH(k - 1, (k == nPhoto - 1 ? 0 : k), RingH[k]);
		outputH((k == nPhoto - 1 ? 0 : k), k - 1, RingH[k].inv());
	}

	for (int s = 0; s <= 1; s++) {
		for (int l = 0; l < nSideLayer; l++) {
			cout << "Layer " << (l + 1) << (s == 0 ? " up: " : " down: ") << endl;
			if (nPhotoSide[s][l] > 0) {
				Mat* newRing = SideRing[s][l];
				Mat* oldRing = l > 0 ? SideRing[s][l - 1] : Ring;
				Mat* newRingOriginal = SideRingOriginal[s][l];
				Mat* oldRingOriginal = l > 0 ? SideRingOriginal[s][l - 1] : RingOriginal;
				Mat* newRot = SideRot[s][l];
				Mat* oldRot = l > 0 ? SideRot[s][l - 1] : Rot;
				int* newIndex = sideIndex[s][l];
				int* oldIndex = l > 0 ? sideIndex[s][l - 1] : index;
				int newN = nPhotoSide[s][l];
				int oldN = l > 0 ? nPhotoSide[s][l - 1] : nPhoto - 1;

				for (int i = 0; i < newN; i++) {
					cout << "Photo " << i << endl;

					Mat Hhorizon = findCentricPhotoHomography(newRing[i], newRing[(i + 1) % newN]);
					outputH(newIndex[i], newIndex[(i + 1) % newN], Hhorizon);
					outputH(newIndex[(i + 1) % newN], newIndex[i], Hhorizon.inv());

					int loweri = (int)round(i * ((double)oldN) / newN);
					if (loweri == oldN) loweri = 0;
					Mat Hvertical = findCentricPhotoHomography(oldRing[loweri], newRing[i]);
					outputH(oldIndex[loweri], newIndex[i], Hvertical);
					outputH(newIndex[i], oldIndex[loweri], Hvertical.inv());
				}
			}
		}
	}
	o.close();
}

void inputFile() {
	// read external rotation info
	ifstream rotFile;
	rotFile.open("rotation_result.txt");
	Mat RotBase;
	for (int i = 0; i < nPhoto - 1; i++) {
		rotFile >> cRing[i];
		Rot[i].create(3, 3, CV_64F);
		for (int j = 0; j < 9; j++) {
			rotFile >> Rot[i].at<double>(j % 3, j / 3);
		}
		Rot[i] = Rot[i].t();
		if (i == 0) {
			RotBase = Rot[0].clone();
		}
		Rot[i] = Rot[i] * RotBase.t();
		if (abs(cRing[i] - 1800) < 200)
			project(Rot[i], RingOriginal[i], cRing[i]);
	}
	for (int s = 0; s <= 1; s++) {
		for (int l = 0; l < nSideLayer; l++) {
			for (int i = 0; i < nPhotoSide[s][l]; i++) {
				rotFile >> cSideRing[s][l][i];
				SideRot[s][l][i].create(3, 3, CV_64F);
				for (int j = 0; j < 9; j++) {
					rotFile >> SideRot[s][l][i].at<double>(j % 3, j / 3);
				}
				SideRot[s][l][i] = SideRot[s][l][i].t();
				SideRot[s][l][i] = SideRot[s][l][i] * RotBase.t();
				if (abs(cSideRing[s][l][i] - 1800) < 200)
					project(SideRot[s][l][i], SideRingOriginal[s][l][i], cSideRing[s][l][i]);
			}
		}
	}

	cout << "Writing to file..." << endl;
	for (int i = 0; i < 6; i++) {
		char filename[50];
		sprintf(filename, "../SKYBOX-%d.PNG", i);
		imwrite(filename, Faces[i]);
		cout << filename << endl;
	}
	cout << "All done" << endl;

	imshow("Match", bigR);
	waitKey(0);
}


int main() {
	init();

	// Do this if you want to export homography data for the solver
	//outputFile();

	// Do this if you want to read the result of the solver and create the skybox
	inputFile();

	return 0;
}

