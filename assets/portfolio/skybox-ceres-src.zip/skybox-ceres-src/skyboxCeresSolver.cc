// Ceres Solver - A fast non-linear least squares minimizer
// Copyright 2015 Google Inc. All rights reserved.
// http://ceres-solver.org/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright notice,
//   this list of conditions and the following disclaimer in the documentation
//   and/or other materials provided with the distribution.
// * Neither the name of Google Inc. nor the names of its contributors may be
//   used to endorse or promote products derived from this software without
//   specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

#include "ceres/ceres.h"
#include "ceres/rotation.h"
#include "glog/logging.h"

#include <iostream>
#include <fstream>

using ceres::AutoDiffCostFunction;
using ceres::CostFunction;
using ceres::Problem;
using ceres::Solver;
using ceres::Solve;

struct HomographyError {
  HomographyError(const double* origin_xi, const double* origin_yi, const double* observed_xi, const double* observed_yi) {
    for (int i = 0; i < 9; i++) {
      origin_x[i] = origin_xi[i];
      origin_y[i] = origin_yi[i];
      observed_x[i] = observed_xi[i];
      observed_y[i] = observed_yi[i];
    }
  }

  template <typename T>
  bool operator()(const T* const camera1, const T* const camera2, T* residuals) const {
    // camera[0,1,2] are the angle-axis rotation.
    T R1[9];
    T R2[9];
    ceres::AngleAxisToRotationMatrix<T>(camera1, R1);
    ceres::AngleAxisToRotationMatrix<T>(camera2, R2);

    T H12[9];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        H12[i+3*j] = T(0);
        for (int k = 0; k < 3; k++) {
          H12[i+3*j] += R2[k+3*i] * R1[k+3*j]; 
        }
      }
    }
    H12[0+3*2] *= camera1[3];
    H12[1+3*2] *= camera1[3];
    H12[2+3*2] *= camera1[3] / camera2[3];
    H12[2+3*1] /= camera2[3];
    H12[2+3*0] /= camera2[3];

    for (int i = 0; i < 9; i++) {
      T predicted_x = H12[0+3*0] * T(origin_x[i]) + H12[0+3*1] * T(origin_y[i]) + H12[0+3*2];
      T predicted_y = H12[1+3*0] * T(origin_x[i]) + H12[1+3*1] * T(origin_y[i]) + H12[1+3*2];
      T predicted_z = H12[2+3*0] * T(origin_x[i]) + H12[2+3*1] * T(origin_y[i]) + H12[2+3*2];
      predicted_x /= predicted_z;
      predicted_y /= predicted_z;

      residuals[i*2] = predicted_x - T(observed_x[i]);
      residuals[i*2+1] = predicted_y - T(observed_y[i]);
    }
    return true;
  }


  // Factory to hide the construction of the CostFunction object from
  // the client code.
  static ceres::CostFunction* Create(const double* origin_x, const double* origin_y, const double* observed_x, const double* observed_y) {
    return (new ceres::AutoDiffCostFunction<HomographyError, 18, 4, 4>(new HomographyError(origin_x, origin_y, observed_x, observed_y)));
  }

  double origin_x[9];
  double origin_y[9];
  double observed_x[9];
  double observed_y[9];
};

int main(int argc, char** argv) {
  google::InitGoogleLogging(argv[0]);

  int nPhoto;
  int nRelation;
  int nRing;
  int* ringSize;
  int* relationFrom;
  int* relationTo;
  double* relationPxOrigin;
  double* relationPyOrigin;
  double* relationPxObserved;
  double* relationPyObserved;
  double** cameraRotations;

  std::ifstream file;
  file.open("solver_input.txt");
  if (!file.is_open()) {
    std::cout << "solver_input.txt not found!" << std::endl; 
    return 0;
  }
  file >> nPhoto;
  file >> nRelation;
  file >> nRing;
  ringSize = new int[nRing];
  for (int i = 0; i < nRing; i++) {
    file >> ringSize[i];
  }
  cameraRotations = new double*[nPhoto];
  int r = 0;
  int n = 0;
  for (int i = 0; i < nPhoto; i++) {
    cameraRotations[i] = new double[4];
    cameraRotations[i][0] = 0;
    cameraRotations[i][1] = n * 2 * 3.14159 / ringSize[r];
    cameraRotations[i][2] = 0;
    cameraRotations[i][3] = 800;
    n++;
    if (n >= ringSize[r]) {
      n = 0;
      r++;
    }
  }
  
  relationFrom = new int[nRelation];
  relationTo = new int[nRelation];
  relationPxOrigin = new double[nRelation];
  relationPyOrigin = new double[nRelation];
  relationPxObserved = new double[nRelation];
  relationPyObserved = new double[nRelation];
  for (int i = 0; i < nRelation; i++) {
    file >> relationFrom[i];
    file >> relationTo[i];
    file >> relationPxOrigin[i];
    file >> relationPyOrigin[i];
    file >> relationPxObserved[i];
    file >> relationPyObserved[i];
  }
  file.close();

  ceres::Problem problem;
  for (int i = 0; i < nRelation / 9; i++) {
    //std::cout << relationPxOrigin[i] << " " << relationPyOrigin[i] << " " << relationPxObserved[i] << " " << relationPyObserved[i] << std::endl;
    ceres::CostFunction* cost_function = HomographyError::Create(relationPxOrigin + i * 9, relationPyOrigin + i * 9, relationPxObserved + i * 9, relationPyObserved + i * 9);
    problem.AddResidualBlock(cost_function, new ceres::HuberLoss(30), cameraRotations[relationFrom[i * 9]], cameraRotations[relationTo[i * 9]]);
  }

  // Run the solver!
  ceres::Solver::Options options;
  options.max_num_iterations = 500;
  options.function_tolerance = 1e-10;
  options.use_inner_iterations = true;
  options.linear_solver_type = ceres::DENSE_SCHUR;
  options.minimizer_progress_to_stdout = true;
  ceres::Solver::Summary summary;
  ceres::Solve(options, &problem, &summary);
  std::cout << summary.FullReport() << "\n";
  std::ofstream outfile;
  outfile.open("rotation_result.txt");
  for (int i = 0; i < nPhoto; i++) {
    outfile << cameraRotations[i][3];
    double matrix[9];
    ceres::AngleAxisToRotationMatrix<double>(cameraRotations[i], matrix);
    for (int j = 0; j < 9; j++) {
      outfile << " " << matrix[j];
    }
    outfile << std::endl;
  }
  outfile.close();
  return 0;
}
