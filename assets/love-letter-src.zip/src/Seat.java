
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Seat implements ActionListener {
	GameRoom gameRoom;
	int index;
	boolean playerConnected = false;
	boolean prepared = false;
	Player player;
	
	Seat(int index, GameRoom gameRoom) {
		this.index = index;
		this.gameRoom = gameRoom;
	}
	
	public void addPlayer(Player player) {
		if (!playerConnected) {
			this.player = player;
			player.seat = this;
			playerConnected = true;
			
			if (player.isMe) {
				enter.setText(Text.leaveButtonText);
			} else {
				enter.setVisible(false);
			}
			information.setText(String.format(Text.informationText, player.name));
		} else {
			//System.out.println("Error: Seat #" + index + " already has a player!");
		}
	}
	
	public void removePlayer() {
		if (playerConnected) {
			playerConnected = false;
			prepared = false;
			
			information.setText(Text.nobody);
			readyLabel.setVisible(false);
			if (player.isMe) {
				enter.setText(Text.enterButtonText);
			} else if (gameRoom.myIndex > -1) {
				enter.setVisible(false);
			} else {
				enter.setVisible(true);
			}
		} else {
			System.out.println("Error: Seat #" + index + " doesn't have any player to remove!");
		}
	}
	
	public void ready() {
		if (playerConnected) {
			prepared = true;
			readyLabel.setVisible(true);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (gameRoom.myIndex == -1) {
			addPlayer(gameRoom.me);
			gameRoom.myIndex = index;
			gameRoom.mainPlayerEnter();
			gameRoom.sendEnter(player.name, index);
		} else {
			gameRoom.sendLeave(player.name, index);
			removePlayer();
			gameRoom.myIndex = -1;
			gameRoom.mainPlayerLeave();
		}
		
		gameRoom.refreshCounter();
	};
	
	
	JPanel panel;
	JLabel seatLabel;
	JButton enter;
	JTextArea information;
	JLabel readyLabel;
	
	public void initializeView(JPanel panel) {
		this.panel = panel;
		
		GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(10,0,0,0);
        
        seatLabel = new JLabel(Text.seatLabelText[index],0);
        seatLabel.setFont(Style.defaultFont);
		
		enter = new JButton(Text.enterButtonText);
		//enter.setName("enter"+index);
		enter.addActionListener(this);
		
		information = new JTextArea(Text.nobody);
		information.setEditable(false);
		
		readyLabel = new JLabel(Text.readyLabelText);
		readyLabel.setVisible(false);
		
		panel.add(seatLabel,c);
		c.gridy++;
		panel.add(enter,c);
		c.gridy++;
		panel.add(information,c);
		c.gridy++;
		panel.add(readyLabel,c);
		
	}

}
