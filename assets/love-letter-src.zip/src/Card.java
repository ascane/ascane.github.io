
public class Card {
	
	private String name,description;
	private int point;
	
	Card(int point){
		this.point = point;
		switch(point){
		case 1:
			name = "Guard";
			description = "Name a non-guard card and choose another player, if that player has that card, he or she is out of the round.";
			break;
		case 2:
			name = "Priest";
			description = "Look at another player's hand.";
			break;
		case 3:
			name = "Baron";
			description = "You and another player secretly compare hands, the player with the lower value is out of the round.";
			break;
		case 4:
			name = "Handmaid";
			description = "Until your next turn, ignore all effects from other players' cards";
			break;
		case 5:
			name = "Prince";
			description = "Choose any player (including yourself) to discard his or her hand and draw a new card.";
			break;
		case 6:
			name = "King";
			description = "Trade hands with another player of your choice.";
			break;
		case 7:
			name = "Countess";
			description = "If you have this card and the King or Prince in your hand, you must discard this card.";
			break;
		case 8:
			name = "Princess";
			description = "If you discard this card, you are out of the round.";
			break;
		}
	}
	
	public String getName(){
		return name;
	}
	
	public int getPoint(){
		return point;
	}
	
	public String getDescription(){
		return description;
	}
	
}
