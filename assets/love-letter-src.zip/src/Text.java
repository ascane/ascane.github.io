
public class Text {
	public static String title = "love letter game room";
	public static String nobody = "nobody is here";
	public static String informationText = "%s is connected";
	public static String readyLabelText = "ready!";
	public static String readyButtonText = "ready!";
	public static String[] seatLabelText = {"South", "East", "North", "West"};
	public static String centerTextS = "person is connected.";
	public static String centerTextM = "people are connected.";
	public static String enterButtonText = "Enter!";
	public static String leaveButtonText = "Leave";
	public static String[] randomName = {"Rabbit", "Chia-man", "Ruoqi", "DE", "Benito", "lol"};
}
