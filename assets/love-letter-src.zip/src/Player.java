
public class Player {
	public String name;
	public Seat seat;
	public Boolean isMe;
	
	Player(String name, Boolean isMe) {
		this.name = name;
		this.isMe = isMe;
	}
}
