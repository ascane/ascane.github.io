
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.util.concurrent.ConcurrentHashMap;


public class MyServer {
	ConcurrentHashMap<String, String> playerStatuses;
	ConcurrentHashMap<String, Integer> ready;
	ConcurrentHashMap<String, String> ips;
	ConcurrentHashMap<Integer, String> playerPositions;
	ConcurrentHashMap<Socket, String> sockets;
	KeyPair serverKeyPair;
	ConcurrentHashMap<String, PublicKey> clientPublicKeys;
	static String[] subDeck, startingHands;

	public static void main(String args[]) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
		new MyServer().go();
	}

	public void go() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
		System.out.println("server starts");
		sockets = new ConcurrentHashMap<Socket, String>();
		playerStatuses = new ConcurrentHashMap<String, String>();
		playerPositions = new ConcurrentHashMap<Integer, String>();
		ips = new ConcurrentHashMap<String, String>();
		ready = new ConcurrentHashMap<String, Integer>();
		SecureRandom random = new SecureRandom();
		serverKeyPair = JSRB.generatedKeyPair(random);
		clientPublicKeys = new ConcurrentHashMap<String, PublicKey>();
		try {
			ServerSocket serverSock = new ServerSocket(5000);
			while (true) {
				Socket cSocket = serverSock.accept();
				Thread t = new Thread(new Process(cSocket));
				t.start();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
			
	}

	public class Process implements Runnable {
		BufferedReader reader;
		Socket sock;
		InputStream is;
		public Process(Socket cSocket) {
			try {
				sock = cSocket;
				is = sock.getInputStream();
				InputStreamReader isReader = new InputStreamReader(sock.getInputStream());
				reader = new BufferedReader(isReader);
			} catch (Exception ex) {
				System.out.println("connection failed");
			}
		}

		public void run() {
			// send its public key to the client just connected and receive the public key of the client
			PrintStream writer;
			try {
				writer = new PrintStream(sock.getOutputStream());
				JSRB.sendInt(writer, serverKeyPair.getPublic().getEncoded().length);
				writer.write(serverKeyPair.getPublic().getEncoded());
				writer.flush();
				int namesize = JSRB.receiveInt(is);
				byte[] nameAr = JSRB.receiveByte(is, namesize);
				String clientName = JSRB.byteToString(nameAr);
				int cpksize = JSRB.receiveInt(is);
				byte[] clientPK = JSRB.receiveByte(is, cpksize);
				PublicKey clientPublicKey = JSRB.decodeX509(clientPK);
				clientPublicKeys.put(clientName, clientPublicKey);
				
			} catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String status;
			try {
				sockets.put(sock, "");
				for(String player : playerStatuses.keySet()){ //tell all new statuses
					tellAllStatuses(playerStatuses.get(player), player);
				}
				tellAll("OK");
				while ((status = reader.readLine()) != null) { // status =
																// id:pos:enter:ready
					if(status.equals("start")){
						Deck d = new Deck();
						d.initializeAndShuffle();
						String deck = d.sendTheDeck();
						subDeck = deck.split(" ");
						startingHands = subDeck[0].split(":");
						startGame();
						break;
					}
					String[] strs = status.split(":");
					if(strs.length==2){
						String name = strs[0];
						sockets.remove(sock);
						playerPositions.remove(name);
						playerStatuses.remove(name);
						ips.remove(name);
						ready.remove(name);
						continue;
					}
					String player = strs[0];
					sockets.put(sock, player);
					ips.put(player, sock.getInetAddress().toString().substring(1)+":"+sock.getPort());
					playerPositions.put(Integer.parseInt(strs[1]), player);
					playerStatuses.put(player, status); //update his status
					tellAllStatuses(playerStatuses.get(player), player);
					ready.put(player, Integer.parseInt(strs[3]));
					
					int totalReady = 0;
					for(int i : ready.values()){
						totalReady += i;
					}
					if (totalReady == 4){
						tellAll("start");
					}
				}
				
			} catch (Exception e) {
				
			}
		}

		private void tellAll(String command) {
			for(Socket socket : sockets.keySet()){
				try {
					if(!socket.isClosed()){
						PrintStream writer = new PrintStream(socket.getOutputStream());
						writer.println(command);
						writer.flush();
					}
				} catch (Exception ex) {
					System.out.println("connection failed");
				}
			}
		}

		private void startGame() {
			Bob serverBob;
			byte[] serverBobECDH;
			byte[] serverBobECDHSign;
			byte[] clientAliceECDH;
			byte[] clientAliceECDHSign;
			byte[] iv;
			byte[] ivSign;

			try {
				//for (Socket socket : sockets.keySet()) {
					String me = sockets.get(sock);
					PrintStream writer = new PrintStream(sock.getOutputStream());
					writer.println(ips.get(me)); //send my ip
					for(String name : ips.keySet()){ //send other ips
						if(!name.equals(me))
							writer.println(ips.get(name));
					}
					//send ciphered deck information to every client
					serverBob = new Bob(serverKeyPair.getPrivate().getEncoded(), clientPublicKeys.get(me).getEncoded());
					writer.println("serverBobReady");
					int cAEsize = JSRB.receiveInt(is);
					clientAliceECDH = JSRB.receiveByte(is, cAEsize);
					int cAESsize = JSRB.receiveInt(is);
					clientAliceECDHSign = JSRB.receiveByte(is, cAESsize);
					serverBobECDH = serverBob.getECDHPublicKeyPhase2(clientAliceECDH, clientAliceECDHSign);
					serverBobECDHSign = serverBob.getSignature(serverBobECDH);
					JSRB.sendInt(writer, serverBobECDH.length);
					writer.write(serverBobECDH);
					writer.flush();
					JSRB.sendInt(writer, serverBobECDHSign.length);
					writer.write(serverBobECDHSign);
					writer.flush();
					int ivsize = JSRB.receiveInt(is);
					iv = JSRB.receiveByte(is, ivsize);
					int ivSsize = JSRB.receiveInt(is);
					ivSign = JSRB.receiveByte(is, ivSsize);
					serverBob.setIV(iv, ivSign);
					for(int pos : playerPositions.keySet()){
						if(playerPositions.get(pos).equals(me)){
							String s = "";
							for(int i = 0; i < 4; i++)
								s += playerPositions.get((pos+i)%4)+":";
							for(int i = 0; i < 4; i++)
								s += startingHands[(pos + i) % 4]+((i < 3)?":":"");
							String deckInfo = pos + " " + s + " " + subDeck[1];
							byte[] cipheredDeckInfo = serverBob.cipher(JSRB.stringToByte(deckInfo));
							JSRB.sendInt(writer, cipheredDeckInfo.length);
							writer.write(cipheredDeckInfo);
							writer.flush();
						}
					}
				//}
//				for(Socket s : sockets.keySet())
					removeAndClose();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}
		
		public void removeAndClose() throws IOException{
			String player = sockets.get(sock);
			playerStatuses.remove(player);
			ready.remove(player);
			ips.remove(player);
			playerPositions.remove(player);
			sockets.remove(sock);
			clientPublicKeys.remove(player);
			sock.close();
		}
		
		
		public void tellAllStatuses(String status, String me) { // tell all others except me
			for(Socket socket : sockets.keySet()){
				try {
					if(!sockets.get(socket).equals(me)&&!socket.isClosed()) {
						PrintStream writer = new PrintStream(socket.getOutputStream());
						writer.println(status);
						writer.flush();
					}
				} catch (Exception ex) {
					System.out.println("connection failed");
				}
			}
		}
	}
}