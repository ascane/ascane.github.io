
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.InvalidKeySpecException;

import javax.swing.*;

public class MyClient extends JFrame implements ActionListener {  

	private static final long serialVersionUID = 1L;
	BufferedReader reader;
	PrintStream writer;
	Socket sock;
	String name;
	String ip;
	JPanel connectPanel  = new JPanel();
	JLabel jlname = new JLabel("Name :       ");
	JTextField jfname = new JTextField("somebody", 13);
	JLabel jlip = new JLabel("Server ip : ");
	JTextField jfip = new JTextField("127.0.0.1", 13); //quei:129.104.216.68 chia:129.104.212.165
	GameRoom gr;
	boolean connected = false;
	KeyPair myKeyPair;
	PublicKey serverPublicKey;
	
	MyClient() {
		setTitle("Connection Window");
		setVisible(true);
		setSize(new Dimension(300,300));
		setLocation(400, 150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JButton connect = new JButton("Connect");
		connect.addActionListener(this);
		connectPanel.add(jlname);
		connectPanel.add(jfname);
		connectPanel.add(jlip);
		connectPanel.add(jfip);
		connectPanel.add(connect);
		add(connectPanel);
		
		validate();
	}
	
	public static void main(String[] args) throws InterruptedException, NoSuchAlgorithmException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		MyClient myClient = new MyClient();
		while(!myClient.connected){
			Thread.sleep(20);
		}
		myClient.establishConnection();
		// receiving the status sent by server		
		Thread t = new Thread(myClient.new incomingReader());
		t.start();
		while(true){
			Thread.sleep(20);
			if (myClient.gr.gameReady()) break;
		}
		System.out.println("The Game starts!");
		myClient.gr.dispose();     
	}

	public void establishConnection() throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		try{
			sock = new Socket(ip, 5000);
			InputStream is = sock.getInputStream();
			InputStreamReader streamReader = new InputStreamReader(is);  
			reader = new BufferedReader(streamReader);

			writer = new PrintStream(sock.getOutputStream());
			System.out.println("connection established" + sock.getInetAddress().toString() + " " + sock.getLocalPort());    
			
			SecureRandom random = new SecureRandom();
			myKeyPair = JSRB.generatedKeyPair(random);
			
			// send its public key to the server and receive the public key of the server
			byte[] nameAr = JSRB.stringToByte(name);
			JSRB.sendInt(writer, nameAr.length);
			writer.write(nameAr);
			writer.flush();
			JSRB.sendInt(writer, myKeyPair.getPublic().getEncoded().length);
			writer.write(myKeyPair.getPublic().getEncoded());
			writer.flush();
			int spksize = JSRB.receiveInt(is);
			byte[] serverPK = JSRB.receiveByte(is, spksize);
			serverPublicKey = JSRB.decodeX509(serverPK);
			
		}catch(IOException ex) {
			System.out.println("connection failed");
		}
	}

	public class incomingReader implements Runnable{
		public void run(){
			String message;
			try{
				while ((message = reader.readLine()) != null){
					if(message.equals("OK")){
						gr.OK = true;
					}
					else if(message.equals("start")){
						writer.println("start");
					}
					else if(message.equals("serverBobReady")){
						recvBobReady();
					} else {
						gr.recvMessage(message);
					}
					
				}
			}catch(Exception e){dispose();}
		}
	}
	
	public void sendClose(){
		writer.println(name+":close");
		
	}
	
	public void sendEnter(String name, int index) {
		writer.println(name + ":" + index + ":1:0");
	}
	
	public void sendLeave(String name, int index) {
		writer.println(name + ":" + index + ":0:0");
	}
	
	public void sendReady(String name, int index) {
		writer.println(name + ":" + index + ":1:1");
	}
	
	public void recvBobReady() {
		try{
			InputStream is = sock.getInputStream();
			Alice clientAlice = new Alice(myKeyPair.getPrivate().getEncoded(), serverPublicKey.getEncoded());
			byte[] clientAliceECDH = clientAlice.generateECDHPublicKey();
			byte[] clientAliceECDHSign = clientAlice.getSignature(clientAliceECDH);
			byte[] serverBobECDH;
			byte[] serverBobECDHSign;
			byte[] iv;
			byte[] ivSign;

			JSRB.sendInt(writer, clientAliceECDH.length);
			writer.write(clientAliceECDH);
			writer.flush();
			JSRB.sendInt(writer, clientAliceECDHSign.length);
			writer.flush();
			writer.write(clientAliceECDHSign);
			writer.flush();
			int sBEsize = JSRB.receiveInt(is);
			serverBobECDH = JSRB.receiveByte(is, sBEsize);
			int sBESsize = JSRB.receiveInt(is);
			serverBobECDHSign = JSRB.receiveByte(is, sBESsize);
			clientAlice.generateAESSecret(serverBobECDH, serverBobECDHSign);
			iv = clientAlice.getIV();
			ivSign = clientAlice.getSignature(iv);		
			JSRB.sendInt(writer, iv.length);
			writer.write(iv);
			writer.flush();
			JSRB.sendInt(writer, ivSign.length);
			writer.write(ivSign);
			writer.flush();
			int cDIsize = JSRB.receiveInt(is);
			byte[] cipheredDeckInfo = JSRB.receiveByte(is, cDIsize);
			String decipheredMessage = new String(clientAlice.decipher(cipheredDeckInfo),"UTF8");
			gr.recvMessage(decipheredMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		name = jfname.getText();
		ip = jfip.getText();
		gr = new GameRoom(name);
		gr.myClient = this;
		connected = true;
		dispose();
	}


}