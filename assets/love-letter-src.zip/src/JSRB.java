import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.*;
import java.security.spec.*;

import javax.crypto.*;
import javax.crypto.spec.*;


public class JSRB {
	
	static KeyPair generatedKeyPair(SecureRandom random)
		throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
		kpg.initialize(128, random);
		KeyPair kp = kpg.generateKeyPair();
		return kp;
	}
	
	static PrivateKey decodePKC8(byte[] key) throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeyFactory kf = KeyFactory.getInstance("EC");
		PrivateKey pk = kf.generatePrivate(new PKCS8EncodedKeySpec(key));
		return pk;
	}
	
	static PublicKey decodeX509(byte[] key) throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeyFactory kf = KeyFactory.getInstance("EC");
		PublicKey pk = kf.generatePublic(new X509EncodedKeySpec(key));
		return pk;
	}
	
	static byte[] getSignature(byte[] message, PrivateKey privateKey, SecureRandom random)
		throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, SignatureException {
		Signature s = Signature.getInstance("SHA512withECDSA");
		s.initSign(privateKey, random);
		s.update(message);
		return s.sign();
	}
	
	static boolean checkSignature(byte[] message, byte[] sign, PublicKey publicKey)
		throws InvalidKeyException, NoSuchAlgorithmException, SignatureException {
		Signature s = Signature.getInstance("SHA512withECDSA");
		s.initVerify(publicKey);
		s.update(message);
		return s.verify(sign);
	}
	
	static byte[] cipher(byte[] text, byte[] iv, SecretKey aesSecret, SecureRandom random)
		throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec ips = new GCMParameterSpec(128, iv);
		c.init(Cipher.ENCRYPT_MODE, aesSecret, ips, random);
		return c.doFinal(text);
	}
	
	static byte[] decipher(byte[] text, byte[] iv, SecretKey aesSecret, SecureRandom random)
		throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec ips = new GCMParameterSpec(128, iv);
		c.init(Cipher.DECRYPT_MODE, aesSecret, ips, random);
		return c.doFinal(text);
	}
	
	static byte[] stringToByte(String s) throws UnsupportedEncodingException {
		return s.getBytes("UTF8");
	}
	
	static String byteToString(byte[] b) throws UnsupportedEncodingException {
		return new String(b,"UTF8");
	}
	
	static byte[] receiveByte(InputStream is, int size) throws IOException{
		int totalBytesRead = 0;
		byte[] B = new byte[size];
        while(totalBytesRead < size){ // very very important!! make sure that all bytes sent are read before receiving the next stream!!!!!
        	byte[] localBuffer = new byte[size-totalBytesRead];
        	int localBytesRead = is.read(localBuffer);
        	for(int i=0;i<localBytesRead;i++)
        		B[i+totalBytesRead] = localBuffer[i];
        	totalBytesRead += localBytesRead;
        }
        return B;
	}
	
	static int receiveInt(InputStream is) throws IOException{
		byte[] sizeAr = receiveByte(is, 4);
		return ByteBuffer.wrap(sizeAr).asIntBuffer().get();
	}
	
	static void sendInt(PrintStream writer, int length) throws IOException{
		byte[] sizeAr = ByteBuffer.allocate(4).putInt(length).array();
		writer.write(sizeAr);
		writer.flush();
	}
}