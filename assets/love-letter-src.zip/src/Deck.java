
import java.util.LinkedList;


public class Deck {

	private LinkedList<Card> deck;
	private static final int N = 20; //number of shuffle
	
	Deck(){
		deck = new LinkedList<Card>();
	}
	
	Deck(String deckComposition){ // deckComposition in the form 1:3:etc
		String[] cards = deckComposition.split(":");
		deck = new LinkedList<Card>();
		for(int i=0;i<cards.length;i++)
			deck.add(new Card(Integer.parseInt(cards[i])));
	}
	
	public void initializeAndShuffle(){ // for the server
		Card[] cards = new Card[16];
		for(int i=0;i<5;i++)	// 5 guards
			cards[i] = new Card(1);
		for(int i=5;i<7;i++)	// 2 priests
			cards[i] = new Card(2);
		for(int i=7;i<9;i++)	// 2 barons
			cards[i] = new Card(3);
		for(int i=9;i<11;i++)	// 2 handmaids
			cards[i] = new Card(4);
		for(int i=11;i<13;i++)	// 2 princes
			cards[i] = new Card(5);
		cards[13] = new Card(6);	// 1 king
		cards[14] = new Card(7);	// 1 countess
		cards[15] = new Card(8);	// 1 princess
		for(int i=0;i<N;i++)	//shuffle N times
			shuffleOnce(cards);
		for(int i=0;i<15;i++)	//for 3-4 people, discard one card
			deck.add(cards[i]);
	}
	
	public void shuffleOnce(Card[] cards){ // take one card randomly and put it on top of the deck
		int index = (int)Math.floor(Math.random()*16); // index = 0~15
		if(index==0) // index == 0 nothing changes
			return;
		Card c = cards[index];
		for(int i=index;i>0;i--)
			cards[i] = cards[i-1];
		cards[0] = c;
	}
	
	public Card draw(){
		return deck.poll();
	}
	
	public String sendTheDeck(){ // for the server, to all players in the form 1:2:3:4 5:etc
		String res = "";
		for(int i=0;i<4;i++)
			res+=draw().getPoint()+((i==3)?"":":");
		res+=" ";
		for(int i=0;i<11;i++)
			res+=draw().getPoint()+((i==10)?"":":");
		return res;
	}
	
	public int size(){
		return deck.size();
	}
	
	public boolean isEmpty(){
		return size()==0;
	}

}
