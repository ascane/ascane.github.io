import java.security.*;
import java.security.spec.*;

import javax.crypto.*;
import javax.crypto.spec.*;


public class Alice {
	private PrivateKey alicePrivateKey;
	private PublicKey bobPublicKey;
	private byte[] iv;
	
	public Alice(byte[] alicePrivateKeyEnc, byte[] bobPublicKeyEnc)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		this.alicePrivateKey = JSRB.decodePKC8(alicePrivateKeyEnc);
		this.bobPublicKey = JSRB.decodeX509(bobPublicKeyEnc);
		iv = new byte[64];
		random.nextBytes(iv);
	}
	
	private KeyAgreement keyAgreement;
	private SecureRandom random = new SecureRandom();
	private SecretKey aesSecret;
	
	byte[] generateECDHPublicKey() throws NoSuchAlgorithmException, InvalidKeyException {
		keyAgreement = KeyAgreement.getInstance("ECDH");
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
		kpg.initialize(128);
		KeyPair kp = kpg.generateKeyPair();
		keyAgreement.init(kp.getPrivate(), random);
		return kp.getPublic().getEncoded();
	}
	
	void generateAESSecret(byte[] bobPublic, byte[] sign) throws InvalidKeyException, IllegalStateException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException {
		if (!checkSignature(bobPublic, sign))
			throw new IllegalArgumentException("@@@ Bad Alice signature");
		
		keyAgreement.doPhase(JSRB.decodeX509(bobPublic), true);
		aesSecret = new SecretKeySpec(keyAgreement.generateSecret(), "AES");
	}
	
	byte[] getSignature(byte[] message) throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException {
		return JSRB.getSignature(message, alicePrivateKey, random);
	}
	
	byte[] getIV() {
		return iv;
	}
	
	boolean checkSignature(byte[] message, byte[] signature) throws InvalidKeyException, NoSuchAlgorithmException, SignatureException {
		return JSRB.checkSignature(message, signature, bobPublicKey);
	}
	
	byte[] decipher(byte[] text) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		return JSRB.decipher(text, iv, aesSecret, random);
	}
}
