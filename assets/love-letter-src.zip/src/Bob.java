import java.security.*;
import java.security.spec.*;

import javax.crypto.*;
import javax.crypto.spec.*;

public class Bob {
	PrivateKey bobPrivateKey;
	PublicKey alicePublicKey;
	
	public Bob(byte[] bobPrivateKeyEnc, byte[] alicePublicKeyEnc) throws NoSuchAlgorithmException, InvalidKeySpecException {
		this.bobPrivateKey = JSRB.decodePKC8(bobPrivateKeyEnc);
		this.alicePublicKey = JSRB.decodeX509(alicePublicKeyEnc);
	}
	
	PrivateKey eCDHPrivateKey;
	SecureRandom random = new SecureRandom();
	SecretKey aesSecret;
	byte[] iv;
	
	byte[] getECDHPublicKeyPhase2(byte[] alicePublic, byte[] sign) throws InvalidKeyException, NoSuchAlgorithmException, SignatureException, IllegalStateException, InvalidKeySpecException {
		if (!checkSignature(alicePublic, sign))
			throw new IllegalArgumentException("@@@ Bad Alice signature");

		KeyAgreement keyAgreement = KeyAgreement.getInstance("ECDH");
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
		kpg.initialize(128);
		KeyPair kp = kpg.generateKeyPair();
		keyAgreement.init(kp.getPrivate(), random);
		keyAgreement.doPhase(JSRB.decodeX509(alicePublic), true);
		aesSecret = new SecretKeySpec(keyAgreement.generateSecret(), "AES");
		return kp.getPublic().getEncoded();
	}
	
	byte[] getSignature(byte[] message) throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException {
		return JSRB.getSignature(message, bobPrivateKey, random);
	}
	
	boolean checkSignature(byte[] message, byte[] signature) throws InvalidKeyException, NoSuchAlgorithmException, SignatureException {
		return JSRB.checkSignature(message, signature, alicePublicKey);
	}
	
	byte[] cipher(byte[] text) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		return JSRB.cipher(text, iv, aesSecret, random);
	}
	
	public void setIV(byte[] iv, byte[] ivSign) throws InvalidKeyException, NoSuchAlgorithmException, SignatureException {
		if (!checkSignature(iv, ivSign))
			throw new IllegalArgumentException("@@@ Bad Alice signature");
		this.iv = iv;
	}
}
