import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.swing.*;

public class GamePerspective extends JFrame implements MouseListener, ActionListener{ // this is one player's terminal
	
	private int turn; // indicate whose turn it is
	private int numberOfPlayers;
	private String[] playerNames; // record everyone's name in anticlockwise order
	private Card[] hands; // record everyone's hand in anticlockwise order
	private Card cardRecentlyDrawed;
	private JPanel[] cardPanels; // current player's hands and the center
	private Deck deck;
	private JButton confirm = new JButton("OK");
	private JButton cancel = new JButton("Cancel");
	private JButton restart = new JButton("Restart");
	private JTextArea indication,information;
	private JLabel[] characterSelections;
	private JPanel thisCard;
	private int characterSelected, enemySelected, enemyCharacterSelected = 0;
	private int align0,align1,align2,align3 = 0;
	private int currentSteps, stepsNeeded = 0;
	private ArrayList<ArrayList<Integer>> cardsPlayed;
	private int arrowSource, arrowDestination;
	private boolean terminated = false;
	private boolean[] invincible;
	private boolean[] outOfRound;
	private DatagramChannel channel;
	private ByteBuffer bb;
	private InetSocketAddress myIP;
	private InetSocketAddress[] destinations;
	private String serverIP;
	private boolean initializeCompleted = false;
	
	//public JButton testPlay = new JButton("test");
	
	public GamePerspective() {
		super();
	}

	GamePerspective(String serverIP, String playerNamesAndInitialHands, String deckComposition, String[] destinationIP, String[] destinationPort, int pos) throws IOException { // playerNames in the format "id1:..:idnumberOfPlayers:itialcard:etc" in anticlockwise order from the current player's perspective
		setTitle("love letter client");							  // deckComposition : a string of length 11 of 1~8 separated by ':'
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(400,0);
		setSize(700, 700);
		setVisible(true);
		setResizable(false);		
		setLayout(new BorderLayout(50,50));
		getContentPane().setBackground(Color.WHITE);
		
		String[] strs = playerNamesAndInitialHands.split(":");
		numberOfPlayers = 4;
		playerNames = new String[numberOfPlayers];
		hands = new Card[numberOfPlayers];
		invincible = new boolean[numberOfPlayers];
		outOfRound = new boolean[numberOfPlayers];
		cardsPlayed = new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<numberOfPlayers;i++){
			cardsPlayed.add(i, new ArrayList<Integer>());
			invincible[i] = false;
			outOfRound[i] = false;
		}
		//initialize selection buttons
		characterSelections = new JLabel[7];
		characterSelections[0] = new JLabel("2 Priest",0);
		characterSelections[1] = new JLabel("3 Baron",0);
		characterSelections[2] = new JLabel("4 Handmaid",0);
		characterSelections[3] = new JLabel("5 Prince",0);
		characterSelections[4] = new JLabel("6 King",0);
		characterSelections[5] = new JLabel("7 Countess",0);
		characterSelections[6] = new JLabel("8 Princess",0);
		
		for(int i=0;i<numberOfPlayers;i++){
			playerNames[i] = strs[i];
			hands[i] = new Card(Integer.parseInt(strs[i+numberOfPlayers]));
		}
		
		cardPanels = new JPanel[numberOfPlayers+1];
		for(int i=1;i<numberOfPlayers;i++){
			cardPanels[i] = new JPanel(new GridBagLayout());
			cardPanels[i].setBackground(Color.WHITE);
		}
		
		// set current player's screen
		cardPanels[0] = new JPanel(new GridBagLayout());
		cardPanels[0].setBackground(Color.WHITE);
		confirm.setName("OK");
		confirm.addActionListener(this);
		confirm.setVisible(false);
		cancel.setName("Cancel");
		cancel.addActionListener(this);
		cancel.setVisible(false);
		restart.setName("Restart");
		restart.addActionListener(this);
		restart.setVisible(false);
		indication = new JTextArea(5,10);
		indication.setName("indication");
		indication.setSize(100, 100);
		indication.setLocation(8, 40);
		indication.setForeground(Color.BLUE);
		indication.setFont(new Font("default",Font.BOLD,16));
		indication.setEditable(false);
		indication.setLineWrap(true);
		indication.setWrapStyleWord(true);
		indication.setVisible(false);
		information = new JTextArea(5,10);
		information.setName("personalInformation");
		information.setForeground(Color.BLUE);
		information.setFont(new Font("default",Font.BOLD,16));
		information.setEditable(false);
		information.setLineWrap(true);
		information.setWrapStyleWord(true);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(10,0,70,10);
        cardPanels[0].add(confirm, c);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(60,0,10,10);
        cardPanels[0].add(cancel, c);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(10,0,70,10);
        cardPanels[0].add(restart, c);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 2;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(10,-160,0,100);
        cardPanels[0].add(indication, c);
        cardPanels[0].add(information, c);
        cardPanels[0].setName("MyCards");
        //test
        /*testPlay.setName("test");
        testPlay.addActionListener(this);
		cardPanels[0].add(testPlay);
		*/
        // set ids
        for(int i=0;i<4;i++){
			JLabel name = new JLabel(" "+playerNames[i]);
			name.setFont(Style.defaultFont);
			name.setName("player"+i);
			c.gridx = 0;
	        c.gridy = 0;
	        c.gridwidth = 1;
	        c.gridheight = 1;
	        c.fill = GridBagConstraints.BOTH;
	        c.anchor = GridBagConstraints.CENTER;
	        c.insets = new Insets(10,10,0,5);
			cardPanels[i].add(name,c);
        }
        
		add(BorderLayout.SOUTH,cardPanels[0]);
		add(BorderLayout.EAST,cardPanels[1]);
		add(BorderLayout.NORTH,cardPanels[2]);
		add(BorderLayout.WEST,cardPanels[3]);
		
		// add character selection in the center
		cardPanels[numberOfPlayers] = new JPanel();
		cardPanels[numberOfPlayers].setLayout(new GridLayout(4,2));
		cardPanels[numberOfPlayers].setBackground(Color.WHITE);
		for(int i=0;i<7;i++){
			cardPanels[numberOfPlayers].add(characterSelections[i]);
			characterSelections[i].setName(""+(i+2));
			characterSelections[i].addMouseListener(this);
			characterSelections[i].setFont(Style.defaultFont);
		}
		cardPanels[numberOfPlayers].setVisible(false);
	    add(cardPanels[numberOfPlayers], BorderLayout.CENTER);
		
		addACard(hands[0],0); // current player's card
		addACard(hands[1],1);
		addACard(hands[2],2);
		addACard(hands[3],3);

		
		
		deck = new Deck(deckComposition);
		if(pos==0)
			turn = 0;
		else
			turn = 4-pos;
		addACard(deck.draw(),turn);
		repaint();
		
		//connection
		channel = DatagramChannel.open();
		myIP = new InetSocketAddress(destinationIP[0],Integer.parseInt(destinationPort[0]));
		this.serverIP = serverIP;
		channel.socket().bind(myIP);
		bb = ByteBuffer.allocate(50);
		destinations = new InetSocketAddress[3]; 
		for(int i=0;i<3;i++){
			destinations[i] = new InetSocketAddress(destinationIP[i+1],Integer.parseInt(destinationPort[i+1])+100);
		}
		initializeCompleted = true;
		paint(getGraphics());
	}
	
	public void drawArrow(Graphics g1, int source, int destination) {
		int x1,x2,y1,y2;
		x1=x2=y1=y2=0;
		switch(source){
		case 0:
			x1=350;
			y1=480;
			break;
		case 1:
			x1=480;
			y1=380;
			break;
		case 3:
			x1=220;
			y1=380;
			break;
		case 2:
			x1=350;
			y1=260;
			break;
		}
		switch(destination){
		case 0:
			x2=350;
			y2=480;
			break;
		case 1:
			x2=480;
			y2=380;
			break;
		case 3:
			x2=220;
			y2=380;
			break;
		case 2:
			x2=350;
			y2=260;
			break;
		}
		Graphics2D g = (Graphics2D) g1;

		double dx = x2 - x1, dy = y2 - y1;
		double angle = Math.atan2(dy, dx);
		int len = (int) Math.sqrt(dx * dx + dy * dy);
		AffineTransform at = AffineTransform.getTranslateInstance(x1, y1);
		at.concatenate(AffineTransform.getRotateInstance(angle));
		g.transform(at);

		g.setColor(Color.RED);
		g.setStroke(new BasicStroke(4));
		g.drawLine(0, 0, len, 0);
		g.fillPolygon(new int[] { len + 10, len - 10, len - 10, len + 10 },
				new int[] { 0, -10, 10, 0 }, 4);
	}
	@Override
	public void paint(Graphics g) {
		if(!initializeCompleted)
			return;
		super.paintComponents(g);
		
		g.setColor(Color.GRAY);
		g.setFont(Style.cardFont);
		if(deck!=null&&(deck.size()>1||deck.size()==0)&&!terminated)
			g.drawString("Cards remaining:"+deck.size(), 10,60);
		else if(deck!=null&&deck.size()==1&&!terminated){
			g.setColor(Color.RED);
			g.setFont(Style.deckFont);
			g.drawString("Cards remaining:1", 10,60);
		}
		else if(terminated){
			g.setColor(Color.BLACK);
			g.setFont(Style.cardFont);
			g.drawString("Game terminated", 10,60);
		}

		g.setColor(Color.BLACK);
		g.setFont(Style.bold);
		
		for(int i=0;i<cardsPlayed.get(0).size();i++){ 
			if(i==cardsPlayed.get(0).size()-1){
				g.setColor(Color.MAGENTA); //last step in magenta and bigger
				g.setFont(Style.currentCard);
			}
			g.drawString(""+cardsPlayed.get(0).get(i), 280+40*i, 520);
		}
		
		g.setColor(Color.BLACK);
		g.setFont(Style.bold);
		
		for(int i=0;i<cardsPlayed.get(1).size();i++){ 
			if(i==cardsPlayed.get(1).size()-1){
				g.setColor(Color.ORANGE); 
				g.setFont(Style.currentCard);
			}
			g.drawString(""+cardsPlayed.get(1).get(i), 500, 440-40*i);
		}
		
		g.setColor(Color.BLACK);
		g.setFont(Style.bold);
		
		for(int i=0;i<cardsPlayed.get(2).size();i++){ 
			if(i==cardsPlayed.get(2).size()-1){
				g.setColor(Color.BLUE); 
				g.setFont(Style.currentCard);
			}
			g.drawString(""+cardsPlayed.get(2).get(i), 440-40*i, 240);
		}
		
		g.setColor(Color.BLACK);
		g.setFont(Style.bold);
		
		for(int i=0;i<cardsPlayed.get(3).size();i++){ 
			if(i==cardsPlayed.get(3).size()-1){
				g.setColor(Color.GREEN); 
				g.setFont(Style.currentCard);
			}
			g.drawString(""+cardsPlayed.get(3).get(i), 180, 320+40*i);
		}
		
		if(!(arrowSource==0&&arrowDestination==0)&&(arrowSource!=arrowDestination))
			drawArrow(g, arrowSource, arrowDestination);
		
	}
	
	public void addACard(Card card, int index){ // add a card to player index
		//information.setText("");
		invincible[index]=false;
		cardRecentlyDrawed = card;
		switch(index){
		case 0:
			JPanel aCard = new JPanel();
			aCard.setName(""+card.getPoint());
			aCard.setPreferredSize(new Dimension(120,160));
			aCard.setBackground(Color.WHITE);
			aCard.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			
			JTextArea point = new JTextArea(card.getPoint()+"");
			point.setName(""+card.getPoint());
			aCard.setLayout(null);
			point.setSize(30, 30);
			point.setLocation(8, 5);
			point.setForeground(Color.RED);
			point.setFont(new Font("default",Font.BOLD,27));	
			aCard.add(point);
			
			JTextArea name = new JTextArea(card.getName());
			name.setName(""+card.getPoint());
			name.setSize(70, 30);
			name.setLocation(40, 10);
			name.setForeground(Color.BLACK);
			name.setFont(new Font("default",Font.BOLD,15));
			aCard.add(name);
	        
			JTextArea description = new JTextArea(5,10);
			description.setName(""+card.getPoint());
			description.setSize(105, 115);
			description.setLocation(8, 40);
			description.setText(card.getDescription());
			description.setEditable(false);
			description.setLineWrap(true);
			description.setWrapStyleWord(true);
			aCard.add(description);
			
			GridBagConstraints c = new GridBagConstraints();
	        c.gridx = ++align0;
	        c.gridy = 0;
	        c.gridwidth = 1;
	        c.gridheight = 2;
	        c.fill = GridBagConstraints.BOTH;
	        c.anchor = GridBagConstraints.CENTER;
	        c.insets = new Insets(0,10,0,0);
	        
			cardPanels[0].add(aCard,c);
			name.addMouseListener(this);
			point.addMouseListener(this);
			description.addMouseListener(this);
			break;
		case 1:
			JPanel aCard1 = new JPanel();
			aCard1.setName("player1");
			aCard1.setBackground(Color.BLACK);
			aCard1.setPreferredSize(new Dimension(160,100));
			GridBagConstraints c1 = new GridBagConstraints();
	        c1.gridx = 0;
	        c1.gridy = ++align1;
	        c1.gridwidth = 1;
	        c1.gridheight = 1;
	        c1.fill = GridBagConstraints.BOTH;
	        c1.anchor = GridBagConstraints.CENTER;
	        c1.insets = new Insets(5,0,0,0);
			cardPanels[1].add(aCard1,c1);
			aCard1.addMouseListener(this);
			break;
		case 2:
			JPanel aCard2 = new JPanel();
			aCard2.setName("player2");
			aCard2.setPreferredSize(new Dimension(120,160));
			aCard2.setBackground(Color.BLACK);
			GridBagConstraints c2 = new GridBagConstraints();
	        c2.gridx = ++align2;
	        c2.gridy = 0;
	        c2.gridwidth = 1;
	        c2.gridheight = 1;
	        c2.fill = GridBagConstraints.BOTH;
	        c2.anchor = GridBagConstraints.CENTER;
	        c2.insets = new Insets(0,10,0,0);
			cardPanels[2].add(aCard2,c2);
			aCard2.addMouseListener(this);
			break;
		case 3:
			JPanel aCard3 = new JPanel();
			aCard3.setName("player3");
			aCard3.setBackground(Color.BLACK);
			aCard3.setPreferredSize(new Dimension(160,100));
			GridBagConstraints c3 = new GridBagConstraints();
	        c3.gridx = 0;
	        c3.gridy = ++align3;
	        c3.gridwidth = 1;
	        c3.gridheight = 1;
	        c3.fill = GridBagConstraints.BOTH;
	        c3.anchor = GridBagConstraints.CENTER;
	        c3.insets = new Insets(5,0,0,0);
			cardPanels[3].add(aCard3,c3);
			aCard3.addMouseListener(this);
			break;
		}
		validate();
		repaint();
	}
	
	public void playACard(int player){ // player play a card
		paint(getGraphics());
		information.setVisible(true);
		removeCardFromHand(player);
		
		/*if(player!=0){ // if it's not player0, attack the next one.
			characterSelected = cardRecentlyDrawed.getPoint();
			if(characterSelected==4||characterSelected==7||characterSelected==8)
				enemySelected=player;
			else
				enemySelected = (player+1)%numberOfPlayers;
			while(outOfRound[enemySelected]||invincible[enemySelected]){
				enemySelected=(enemySelected+1)%numberOfPlayers;
			}
			enemyCharacterSelected = 2+(int)Math.floor(6*Math.random());
		}*/
		
		if(hands[player].getPoint()==characterSelected) // if he plays his hand, change.
			hands[player] = cardRecentlyDrawed;
		cardsPlayed.get(player).add(characterSelected);
		arrowSource = player;
		arrowDestination = enemySelected;	
		
		switch(characterSelected){
		case 1:
			if(hands[enemySelected].getPoint()==enemyCharacterSelected){
				information.setText(playerNames[player]+" caught "+playerNames[enemySelected]+", "+playerNames[enemySelected]+"'s out!");
				outOfRound[enemySelected]=true;
			}
			else if(enemySelected==player)
				information.setText("No effect because the others are invincible!");
			else
				information.setText(playerNames[player]+" guessed "+playerNames[enemySelected]+" of "+new Card(enemyCharacterSelected).getName()+" but he didn't guess right.");
			break;
		case 2:
			if(player==0)
				information.setText(playerNames[enemySelected]+"'s card is "+hands[enemySelected].getName());
			else if(enemySelected==player)
				information.setText("No effect because the others are invincible!");
			else
				information.setText(playerNames[player]+" looked at "+playerNames[enemySelected]+"'s card.");
			break;
		case 3:
			if(hands[player].getPoint()<hands[enemySelected].getPoint()){
				if(player==0)
					information.setText(playerNames[enemySelected]+"'s card is "+hands[enemySelected].getName()+", you lost the dual with him and you're out!");
				else if(enemySelected==0)
					information.setText(playerNames[player]+"'s card is "+hands[player].getName()+", he lost the dual with you and he's out!");
				else
					information.setText(playerNames[player]+" lost the dual with "+playerNames[enemySelected]+" and "+playerNames[player]+" is out!");
				outOfRound[player]=true;
			}
			else if(hands[player].getPoint()>hands[enemySelected].getPoint()){
				if(player==0)
					information.setText(playerNames[enemySelected]+"'s card is "+hands[enemySelected].getName()+", you won the dual with him and he's out!");
				else if(enemySelected==0)
					information.setText(playerNames[player]+"'s card is "+hands[player].getName()+", you lost the dual with him and you're out!");
				else
					information.setText(playerNames[player]+" won the dual with "+playerNames[enemySelected]+" and "+playerNames[enemySelected]+" is out!");
				outOfRound[enemySelected]=true;
			}
			
			else{
				if(player==0)
					information.setText(playerNames[enemySelected]+"'s card is "+hands[enemySelected].getName()+", draw and both of you survived!");
				else if(enemySelected==0)
					information.setText(playerNames[player]+"'s card is "+hands[player].getName()+", draw and both of you survived!");
				else
					information.setText(playerNames[player]+" did a dual with "+playerNames[enemySelected]+", draw and both of them survived!");
			}
			break;
		case 4:
			information.setText(playerNames[player]+" is invincible!");
			invincible[player]=true;
			break;
		case 5: 
			princeDiscardAndRedraw(player,enemySelected);
			if(hands[enemySelected]==null)
				information.setText(playerNames[enemySelected]+" discarded the last card, he's out!");
			else if(outOfRound[enemySelected])
				information.setText(playerNames[enemySelected]+" discarded princess, he's out!");
			else
				information.setText(playerNames[enemySelected]+" discarded a card and redrawed a new one.");
			break;
		case 6:
			Card temp;
			temp=hands[enemySelected];
			hands[enemySelected]=hands[player];
			hands[player]=temp;
			information.setText(playerNames[player]+" exchanged his card with "+playerNames[enemySelected]);
			if(enemySelected==player)
				information.setText("No effect because the others are invincible!");
			else if(player==0||enemySelected==0){
				characterSelected=hands[(enemySelected==0)?player:enemySelected].getPoint();
				removeCardFromHand(player);
				addACard(new Card(hands[player].getPoint()), player);
				removeCardFromHand(enemySelected);
				addACard(new Card(hands[enemySelected].getPoint()), enemySelected);
			}
			break;
		case 7:
			information.setText(playerNames[player]+" played courtess.");
			break;
		case 8:
			information.setText(playerNames[player]+" discarded princess, he's out!");
			outOfRound[player]=true;
			break;
		}
		
		int playerOut=0;
		for(int i=0;i<4;i++)
			if(outOfRound[i])
				playerOut++;
		
		
		turn=(turn+1)%numberOfPlayers;
		while(outOfRound[turn]){
			turn=(turn+1)%numberOfPlayers;
		}
		
		invincible[turn]=false;
		updateCard();
		
		if(deck.isEmpty()||playerOut==3){
			terminated = true;
			showResult();
			restart.setVisible(true);
			validate();
			return;
		}
		
		addACard(deck.draw(), turn);
		repaint();
	}
	
	public void updateCard(){
		paint(getGraphics());
		for(int i=0;i<4;i++){
			if(outOfRound[i])
				for(Component c : cardPanels[i].getComponents())
					if(c instanceof JPanel){
						((JPanel) c).setBackground(Color.WHITE);
						((JPanel) c).removeAll();
						JTextArea out = new JTextArea(hands[i].getPoint()+"\nOUT");
						((JPanel) c).setLayout(null);
						out.setSize(80, 70);
						out.setLocation(10, 5);
						out.setForeground(Color.RED);
						out.setFont(new Font("default",Font.BOLD,24));	
						((JPanel) c).add(out);
					}
		}
		for(int i=1;i<4;i++){
			if(invincible[i]){
				for(Component c : cardPanels[i].getComponents())
					if(c instanceof JPanel){
						((JPanel) c).setBackground(Color.WHITE);
						((JPanel) c).removeAll();
						JTextArea inv = new JTextArea("INV");
						((JPanel) c).setLayout(null);
						inv.setSize(60, 40);
						inv.setLocation(10, 5);
						inv.setForeground(Color.RED);
						inv.setFont(new Font("default",Font.BOLD,27));	
						((JPanel) c).add(inv);
					}
			}
			else if(!invincible[i]&&!outOfRound[i]){
				for(Component c : cardPanels[i].getComponents())
					if(c instanceof JPanel){
						((JPanel) c).setBackground(Color.BLACK);
						((JPanel) c).removeAll();
					}
			}
		}
		repaint();
	}
	
	
	public void princeDiscardAndRedraw(int player, int enemy){
		paint(getGraphics());
		if(player==0)
			characterSelected=enemyCharacterSelected;
		else
			characterSelected=hands[enemySelected].getPoint();
		
		if(enemy==0)
			cardsPlayed.get(0).add(characterSelected);
		else
			cardsPlayed.get(enemy).add(hands[enemy].getPoint());
		removeCardFromHand(enemy);
		if(hands[enemy].getPoint()==8){
			outOfRound[enemy]=true;
			addACard(new Card(8),enemy);
			return;
		}
		Card c = deck.draw();
		if(c==null){ // if there's no card anymore
			hands[enemy]=null;
			outOfRound[enemy]=true;
			return;
		}
		addACard(c, enemy);
		hands[enemy]=c;
	}
	
	
	/*public static void main(String[] args) throws IOException, InterruptedException {
//		Deck d = new Deck();
//		d.initializeAndShuffle();
//		String s = "8:1:1:1 1:7:4:3:1:2:5:2:3:4:5";
//		System.out.println(s);
//		GamePerspective frame = new GamePerspective("id0:id1:id2:id3:"+s.split(" ")[0],s.split(" ")[1]); 
//		//GamePerspective frame = new GamePerspective("id0:id1:id2:id3:1:2:3:4","1:1:1:1:2:3:4:5:5:6:7");
//		Thread t = new Thread(frame.new Receiving());
//		t.start();
		GamePerspective gp = new GamePerspective();
		gp.playerNames = new String[3];
		gp.playerNames[0]="aa";
		gp.restart();
	}*/

	@Override
	public void mouseClicked(MouseEvent e) {
		paint(getGraphics());
		if(turn!=0||terminated)
			return;
		//System.out.println("source! "+e.getComponent().getName());
		arrowSource=arrowDestination=0;
		information.setText("");
		information.setVisible(false);
		if(currentSteps==stepsNeeded&&stepsNeeded!=0)
			return;
		
		if(currentSteps==0){
		for(Component c : cardPanels[0].getComponents())
			if(c instanceof JPanel)
				for(Component c2 : ((JPanel) c).getComponents())
					if(e.getSource()==c2){
						indication.setVisible(true);
						if(Integer.parseInt(c.getName())!=7&&(hands[0].getPoint()==7||cardRecentlyDrawed.getPoint()==7)&&(hands[0].getPoint()==5||hands[0].getPoint()==6||cardRecentlyDrawed.getPoint()==5||cardRecentlyDrawed.getPoint()==6)){ //5.7 or 6.7 at the same time
							indication.setText("you have Courtess and King/Prince in your hand, please select Courtess.");
							return;
						}
						(thisCard = (JPanel) c).setBorder(BorderFactory.createLineBorder(Color.RED,5));
						switch(Integer.parseInt(c.getName())){
						case 1:
							characterSelected=1;
							stepsNeeded=3;
							indication.setText("Choose another player's card to attack.");
							break;
						case 2:
							characterSelected=2;
							stepsNeeded=2;
							indication.setText("Choose another player's card to look at.");
							break;
						case 3: 
							characterSelected=3;
							stepsNeeded=2;
							indication.setText("Choose another player's card to compare (with the other card in your hand).");
							break;
						case 4:
							characterSelected=4;
							stepsNeeded=1;
							indication.setText("You'll be resistant to all effect until the next turn.");
							break;
						case 5:
							characterSelected=5;
							stepsNeeded=2;
							indication.setText("Choose a player's card to discard, and he/she redraws a new one.");
							break;
						case 6:
							characterSelected=6;
							stepsNeeded=2;
							indication.setText("Choose another player's card to trade (with the other card in your hand).");
							break;
						case 7:
							characterSelected=7;
							stepsNeeded=1;
							indication.setText("");
							break;
						case 8:
							characterSelected=8;
							stepsNeeded=1;
							indication.setText("Attention! If you discard this card, you'll be out of the round!");
							break;
						}
						currentSteps++;
						cancel.setVisible(true);
						break;
					}

		//for(Component d : cardPanels[0].getComponents())
		//	if(d!=thisOne&&d instanceof JPanel)
		//		((JPanel) d).setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		repaint();
		}
		
		else if(currentSteps==1){
			for(Component c : cardPanels[0].getComponents())
				if(c instanceof JPanel)
					for(Component c2 : ((JPanel) c).getComponents())
						if(e.getSource()==c2){
							if(characterSelected==5&&c!=thisCard){
								((JPanel) c).setBorder(BorderFactory.createLineBorder(Color.RED,5));
								enemySelected=0;
								enemyCharacterSelected = Integer.parseInt(c.getName());
								break;
							}
							return;
						}
			
			if(e.getComponent() instanceof JPanel){
				if(e.getComponent().getBackground()==Color.WHITE) //if the player is already out
					return;
				((JPanel) e.getComponent()).setBorder(BorderFactory.createLineBorder(Color.RED,5));
				enemySelected = e.getComponent().getName().charAt(6)-48;
			}
			indication.setText("");
			currentSteps++;
			if(stepsNeeded==3){
				cardPanels[numberOfPlayers].setVisible(true);
				indication.setText("Choose a character that you guess it is.");
			}
			validate();
			repaint();
		}
		else if(currentSteps==2){
			if(!(e.getComponent() instanceof JLabel))
				return;
			else{
				((JLabel) e.getComponent()).setBorder(BorderFactory.createLineBorder(Color.RED,5));
				enemyCharacterSelected = Integer.parseInt(e.getComponent().getName());
			}
			indication.setText("");
			currentSteps++;
			repaint();
		}
		int playerNonAvailable=0;
		for(int i=1;i<4;i++)
			if(outOfRound[i]||invincible[i])
				playerNonAvailable++;
		if((currentSteps==stepsNeeded&&stepsNeeded!=0)||(playerNonAvailable==3&&characterSelected!=5)){
			confirm.setVisible(true);
			validate();
			repaint();
		}
		
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("Restart")){
			dispose();
			try {
				restart();
			} catch (NoSuchAlgorithmException | InvalidKeySpecException
					| InvalidAlgorithmParameterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return;
		}	
		if(e.getActionCommand().equals("OK")){
			try {
				sendCommand(playerNames[0]+":"+playerNames[enemySelected]+":"+characterSelected+":"+enemyCharacterSelected);
				playACard(0);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			reset();
			return;
		}
		if(e.getActionCommand().equals("Cancel")){
			reset();
			return;
		}
		//test
		if(e.getActionCommand().equals("test")){
			playACard(turn);
			reset();
			return;
		}
	}
	
	public void reset(){
		characterSelected=enemySelected=enemyCharacterSelected=0;
		stepsNeeded=currentSteps=0;
		for(int i=0;i<numberOfPlayers;i++)
			for(Component c : cardPanels[i].getComponents()){
				if(c instanceof JPanel)
					((JPanel) c).setBorder(BorderFactory.createLineBorder(Color.BLACK));
			}
		for(Component c : cardPanels[numberOfPlayers].getComponents()){
			if(c instanceof JComponent)
				((JComponent) c).setBorder(null);
		}
		confirm.setVisible(false);
		cancel.setVisible(false);
		indication.setVisible(false);
		cardPanels[numberOfPlayers].setVisible(false);
		validate();
		repaint();
		return;
	}
	
	public void removeCardFromHand(int player){
		if(player==0){
			for(Component c : cardPanels[player].getComponents())
				if(c.getName().equals(""+characterSelected)){
					cardPanels[player].remove(c);
					break;
				}
			return;
		}
		
		for(Component c : cardPanels[player].getComponents()) // for other players, remove a black card
			if(c instanceof JPanel){
				cardPanels[player].remove(c);
				break;
			}
		return;
	}
	
	public void showResult(){
		int max=0;
		ArrayList<Integer> winners = new ArrayList<Integer>();
		for(int i=0;i<4;i++){
			if(!outOfRound[i]&&hands[i].getPoint()>max){
				max = hands[i].getPoint();
				winners.clear();
				winners.add(i);
			}
			else if(!outOfRound[i]&&hands[i].getPoint()==max){
				winners.add(i);
			}
		}

		for(int i=0;i<4;i++)
			if(!outOfRound[i])
				for(Component c : cardPanels[i].getComponents())
					if(c instanceof JPanel){
						((JPanel) c).setBackground(Color.WHITE);
						((JPanel) c).removeAll();
						JTextArea finalScore = new JTextArea(hands[i].getPoint()+((winners.contains(i))?"\nWIN":"\nLOSE"));
						((JPanel) c).setLayout(null);
						finalScore.setSize(80, 70);
						finalScore.setLocation(10, 5);
						finalScore.setForeground(Color.RED);
						finalScore.setFont(new Font("default",Font.BOLD,24));	
						((JPanel) c).add(finalScore);
					}
	}
	
	public void sendCommand(String s) throws IOException{ //s = idplayer:idenemy:chara:enemyChara
		bb.put(s.getBytes());
		bb.flip();
		for(int i=0;i<3;i++){
			channel.send(bb, destinations[i]);
			bb.flip();
		}
		bb.clear();
	}
	
	public void restart() throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidAlgorithmParameterException, InterruptedException{
		MyClient myClient = new MyClient();
		myClient.dispose();
		myClient.gr = new GameRoom(playerNames[0]);
		myClient.gr.myClient=myClient;
		myClient.name = playerNames[0];
		myClient.ip = serverIP;
		myClient.establishConnection();
		Thread t = new Thread(myClient.new incomingReader());
		t.start();
	}
	
	public class Receiving implements Runnable{
		@Override
		public void run() {
			try {
				DatagramChannel channel = DatagramChannel.open();
				ByteBuffer bb = ByteBuffer.allocate(50);
				channel.socket().bind(new InetSocketAddress(myIP.getPort()+100));
				while(!terminated){
					channel.receive(bb);
					bb.flip();
					byte[] res = new byte[bb.limit()]; // transform ByteBuffer into string
					bb.get(res);
					String s = new String(res);
					String[] strs = s.split(":");
					for(int i=0;i<4;i++){
						if(playerNames[i].equals(strs[0]))
							turn = i;
						if(playerNames[i].equals(strs[1]))
							enemySelected = i;
					}
					characterSelected = Integer.parseInt(strs[2]);
					enemyCharacterSelected = Integer.parseInt(strs[3]);
					playACard(turn);
					reset();
					bb.clear( );
				}
			} catch (Exception e) {
				if (terminated)
					System.out.println("match terminated");
				else
					e.printStackTrace();
			}
		}
		
	}

}
