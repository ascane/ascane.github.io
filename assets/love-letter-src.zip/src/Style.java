
import java.awt.Font;

public class Style {
	public static Font defaultFont = new Font("default", Font.BOLD, 15);
	public static Font cardFont = new Font("default",Font.PLAIN,20);
	public static Font deckFont = new Font("default",Font.BOLD,25);
	public static Font currentCard = new Font("default",Font.BOLD,32);
	public static Font bold = new Font("default",Font.BOLD,30);
}
