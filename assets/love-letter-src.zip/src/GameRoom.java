
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;


public class GameRoom extends JFrame implements ActionListener, WindowListener{
	
	private static final long serialVersionUID = 1L;
	public final int nPlayer = 4;
	public MyClient myClient;
	
	private JPanel centerPanel = new JPanel();
	private JLabel centerLabel = new JLabel();
	private JTextArea centerText = new JTextArea(1,10);
//	private JTextArea testText = new JTextArea(1,10);
//	private JButton testAddB = new JButton();
//	private JButton testLeaveB = new JButton();
//	private JButton testReady = new JButton();
	private JButton ready = new JButton();
//	private JButton connect = new JButton();
	
	private JPanel[] seatPanels = new JPanel[nPlayer];
	
	public Seat[] seats = new Seat[nPlayer];
	
	public Player me; // The player!
	public int myIndex = -1; // the position of the player, -1 means not connected
	private String[] destinationIP = new String[nPlayer];
	private String[] destinationPort = new String[nPlayer];
	private int count = 0;
	public boolean OK = false;
	
	GameRoom(String PlayerName){
		me = new Player(PlayerName, true);
		setTitle(Text.title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(400, 150);
		setSize(500, 500);
		setVisible(true);
		setResizable(false);		
		getContentPane().setBackground(Color.WHITE);
		
		for (int i = 0; i < nPlayer; i++) {
			seatPanels[i] = new JPanel(new GridBagLayout());
		}

		add(BorderLayout.SOUTH,seatPanels[0]);
		add(BorderLayout.EAST,seatPanels[1]);
		add(BorderLayout.NORTH,seatPanels[2]);
		add(BorderLayout.WEST,seatPanels[3]);
		
		for (int i = 0; i < nPlayer; i++) {
			seats[i] = new Seat(i, this);
			seats[i].initializeView(seatPanels[i]);
		}
		
//		centerPanel.setLocation(400,800);
		centerPanel.setSize(50, 50);
		add(BorderLayout.CENTER,centerPanel);
		
		centerLabel.setText(""+0);
		centerPanel.add(centerLabel);
		centerText.setText(Text.centerTextS);
		centerText.setEditable(false);
//		testAddB.setName("testAdd");
//		testAddB.setText("add a player");
//		testAddB.addActionListener(this);
//		testLeaveB.setName("testLeave");
//		testLeaveB.setText("a player leaves");
//		testLeaveB.addActionListener(this);
		ready.setName("ready");
		ready.setText(Text.readyButtonText);
		ready.setVisible(false);
		ready.addActionListener(this);
//		testReady.setName("testReady");
//		testReady.setText("Everybody get ready!");
//		testReady.addActionListener(this);
//		connect.setName("connect");
//		connect.setText("Connect!");
//		connect.addActionListener(this);
		
		centerPanel.add(centerText);
//		centerPanel.add(testText);
//		centerPanel.add(testAddB);
//		centerPanel.add(testLeaveB);
		centerPanel.add(ready);
//		centerPanel.add(testReady);
//		centerPanel.add(connect);
		addWindowListener(this);
		validate();
		
	}
	
	public int countPlayersConnected(){ 
		int temp = 0;
		for (int i = 0; i < nPlayer; i++) {
			if (seats[i].playerConnected) temp++;
		}
		return temp;
	}
	
	boolean gameReady(){ // whether everyone is ready
		for (int i = 0; i < nPlayer; i++) {
			if (!seats[i].prepared) return false;
		}
		return true;
	}
	
	public void mainPlayerEnter() {
		ready.setVisible(true);
		for (int i = 0; i < nPlayer; i++) {
			if (seats[i].index != myIndex)
				seats[i].enter.setVisible(false);
		}
	}
	
	public void mainPlayerLeave() {
		ready.setVisible(false);
		for (int i = 0; i < nPlayer; i++) {
			if (!seats[i].playerConnected)
				seats[i].enter.setVisible(true);
		}
	}
	
	public void refreshCounter() {
		int count = countPlayersConnected();
		centerLabel.setText(""+count);
		centerText.setText(count <= 1 ? Text.centerTextS : Text.centerTextM);
	}

//	public static void main(String[] args) throws InterruptedException {
//		GameRoom gr = new GameRoom("AOI");
//
//		while(true){
//			Thread.sleep(20);
//			if (gr.gameReady()) break;
//		}
//		System.out.println("The Game starts!");
//		gr.dispose();
//	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(!OK)
			return;
		switch (((JButton)e.getSource()).getName()) {
//		case "testAdd": // simulation of adding a player 
//			int notConnected = 0;
//			while (notConnected < nPlayer && seats[notConnected].playerConnected) {
//				notConnected++;
//			}
//			if (notConnected < nPlayer) {
//				String name = Text.randomName[new Random().nextInt(Text.randomName.length)];
//				seats[notConnected].addPlayer(new Player(name, false));
//				testText.setText("");
//			} else {
//				testText.setText("The gameroom is full!");
//			}
//			break;
//		case "testLeave": // simulation of a player leaving
//			int connected = 0;
//			while (connected < nPlayer && (!seats[connected].playerConnected || connected == myIndex)) {
//				connected++;
//			}
//			if (connected < nPlayer) {
//				seats[connected].removePlayer();
//				testText.setText("");
//			} else {
//				testText.setText("No other player is in the gameroom!");
//			}
//			break;
		case "ready": // click on ready
			seats[myIndex].ready();
			sendReady();
			break;
//		case "testReady": // click on testReady
//			for (int i = 0; i < nPlayer; i++) {
//				if (seats[i].playerConnected && !seats[i].player.isMe) {
//					seats[i].ready();
//				}
//			}
//			break;
//		case "connect": // click on connect
//			connect.setVisible(false);
		}
		refreshCounter();
	}
	
	public void sendEnter(String name, int index) {
		if(!OK)
			return;
		myClient.sendEnter(name, index);
	}
	
	public void sendLeave(String name, int index) {
		myClient.sendLeave(name, index);
	}
	
	public void sendReady() {
		myClient.sendReady(me.name, myIndex);
	}
	
	public void recvMessage(String decipheredMessage) throws NumberFormatException, IOException {
		// message = name:index:enter:prepared
		String[] str = decipheredMessage.split(":");
		if (str.length == 4) {
			String name = str[0];
			int index = Integer.parseInt(str[1]);
			boolean enter = (str[2].equals("1"))?true:false;
			boolean prepared = (str[3].equals("1"))?true:false;
			
			if (!enter) {
				seats[index].removePlayer();
			} else{
				Player player = new Player(name, false);
				seats[index].addPlayer(player);
				if (prepared) {
					seats[index].ready();
				}
			}
			refreshCounter();
		}
		else if (str.length == 2) { //ip
			destinationIP[count] = str[0];
			destinationPort[count] = str[1];
			count++;
		}
		else {
			dispose();
			System.out.println("The Game starts!");
			str = decipheredMessage.split(" ");
			String serverIP = myClient.ip;
			GamePerspective gp = new GamePerspective(serverIP,str[1], str[2], destinationIP, destinationPort, Integer.parseInt(str[0]));
			Thread t = new Thread(gp.new Receiving());
			t.start();
		}
	}

	@Override
	public void windowOpened(WindowEvent e) {

		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		if(myIndex!=-1)
			myClient.sendLeave(seats[myIndex].player.name, myIndex);
		myClient.sendClose();
	}

	@Override
	public void windowClosed(WindowEvent e) {
		
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

}


